﻿public class PointCloudFrame: Frame
{
    public FloatPoint[] Points;
}

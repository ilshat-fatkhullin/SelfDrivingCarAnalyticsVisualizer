﻿public class SingleValueFrame: Frame
{
    public float Value;
}

﻿public class PositionFrame: Frame
{
    public FloatPoint Point;
}


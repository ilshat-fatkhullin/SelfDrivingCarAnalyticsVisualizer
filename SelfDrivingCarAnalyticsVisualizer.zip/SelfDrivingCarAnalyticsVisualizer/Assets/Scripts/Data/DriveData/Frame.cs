﻿public abstract class Frame
{
    public float Timestamp;
}

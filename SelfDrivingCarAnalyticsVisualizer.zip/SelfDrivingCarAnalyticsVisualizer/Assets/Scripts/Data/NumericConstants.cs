﻿public static class NumericConstants
{
    public const float EARTH_RADIUS = 6371008;
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MessageBoxSpawner : MonoBehaviour
{
    [SerializeField]
    private GameObject MessageBox;

    private void Start()
    {
        
    }
}

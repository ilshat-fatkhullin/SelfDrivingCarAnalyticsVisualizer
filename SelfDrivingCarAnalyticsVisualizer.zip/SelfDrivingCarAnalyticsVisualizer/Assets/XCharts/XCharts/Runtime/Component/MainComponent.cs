/******************************************/
/*                                        */
/*     Copyright (c) 2018 monitor1394     */
/*     https://github.com/monitor1394     */
/*                                        */
/******************************************/

namespace XCharts
{
    public class MainComponent : ChartComponent
    {
    }
}
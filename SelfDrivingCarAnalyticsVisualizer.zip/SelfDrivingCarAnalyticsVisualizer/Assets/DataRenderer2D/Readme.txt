creator
Kim giwon (https://github.com/geniikw) ,(geniikw@gmail.com)

this asset include these menu

## line
1.GameObject/2D Object/DataRenderer/WorldLine
2.GameObject/2D Object/DataRenderer/UILine
3.GameObject/2D Object/DataRenderer/GizmoLine

## polygon
1.GameObject/2D Object/DataRenderer/WorldPolygon
2.GameObject/2D Object/DataRenderer/UIPolygon 
*Canvas must be in the upper transform of UIPolygon.

## sin
1. GameObject/2D Object/DataRenderer/UISignal (beta)

## hole
1. GameObject/2D Object/DataRenderer/UIHole (beta)

* "UIXXXXX" must create in unity3d canvas.

reference 
https://github.com/HTD/FastBezier
https://en.wikipedia.org/wiki/Bezier_curve